package connectwithsql;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.cinemaapp2.R;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
    }
}