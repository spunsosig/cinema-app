package com.example.cinemaapp2.ui.MovieDetails;

public class MovieDetailsViewModel {
}
