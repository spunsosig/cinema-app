package com.example.cinemaapp2.ui.MovieDetails;

import androidx.fragment.app.Fragment;

import com.example.cinemaapp2.R;

public class MovieDetailsFragment extends Fragment {
    public MovieDetailsFragment(){
        super(R.layout.fragment_movie_details);
    }

    public void onCreateView(){

    }
}
