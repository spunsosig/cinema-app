package com.example.cinemaapp2.api;public interface ApiService {
}
